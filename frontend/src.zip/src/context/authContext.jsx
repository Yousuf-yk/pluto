import {
    createContext,
    useContext,
    useEffect,
    useState,
} from "react";

import {
    getToken,
    getCurrentUser,
    logout as logoutApi,
} from "../services/authApi";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {

    // Get the logged-in user from localStorage
    const [user, setUser] = useState(() => getCurrentUser());

    // Get JWT token from localStorage
    const [token, setToken] = useState(() => getToken());

    // ================================
    // AUTH STATE
    // ================================

    const isAuthenticated = !!token;

    const isAdmin = user?.role === "admin";

    // ================================
    // SYNC AUTH STATE
    // ================================

    useEffect(() => {

        const syncAuth = () => {
            setToken(getToken());
            setUser(getCurrentUser());
        };

        // Useful when localStorage changes
        // from another browser tab
        window.addEventListener("storage", syncAuth);

        return () => {
            window.removeEventListener(
                "storage",
                syncAuth
            );
        };

    }, []);

    // ================================
    // LOGIN
    // ================================

    const login = (authData) => {

        if (!authData) return;

        const {
            token: newToken,
            user: newUser,
        } = authData;

        if (newToken) {
            localStorage.setItem(
                "token",
                newToken
            );

            setToken(newToken);
        }

        if (newUser) {
            localStorage.setItem(
                "user",
                JSON.stringify(newUser)
            );

            setUser(newUser);
        }
    };

    // ================================
    // LOGOUT
    // ================================

    const logout = () => {

        logoutApi();

        setToken(null);
        setUser(null);
    };

    // ================================
    // CONTEXT
    // ================================

    return (
        <AuthContext.Provider
            value={{
                user,
                token,
                isAuthenticated,
                isAdmin,
                login,
                logout,
            }}
        >
            {children}
        </AuthContext.Provider>
    );
}

// ================================
// USE AUTH
// ================================

export function useAuth() {

    const context = useContext(AuthContext);

    if (!context) {
        throw new Error(
            "useAuth must be used inside AuthProvider"
        );
    }

    return context;
}