import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/authContext";

function AdminRoute() {

    const {
        isAuthenticated,
        isAdmin,
    } = useAuth();

    // ================================
    // NOT LOGGED IN
    // ================================

    if (!isAuthenticated) {
        return (
            <Navigate
                to="/login"
                replace
            />
        );
    }

    // ================================
    // LOGGED IN BUT NOT ADMIN
    // ================================

    if (!isAdmin) {
        return (
            <Navigate
                to="/"
                replace
            />
        );
    }

    // ================================
    // ADMIN
    // ================================

    return <Outlet />;
}

export default AdminRoute;