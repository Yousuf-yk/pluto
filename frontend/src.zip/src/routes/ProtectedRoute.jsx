import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:3000/api/auth",
});

// ================================
// REGISTER
// ================================
export const register = async (userData) => {
  try {
    const response = await API.post("/register", userData);
    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

// ================================
// LOGIN
// ================================
export const login = async (userData) => {
  try {
    const response = await API.post("/login", userData);

    localStorage.setItem("token", response.data.token);

    // Store user information including role
    localStorage.setItem(
      "user",
      JSON.stringify(response.data.user)
    );

    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

// ================================
// LOGOUT
// ================================
export const logout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
};

// ================================
// GET TOKEN
// ================================
export const getToken = () => {
  return localStorage.getItem("token");
};

// ================================
// GET CURRENT USER
// ================================
export const getCurrentUser = () => {
  const user = localStorage.getItem("user");

  if (!user) {
    return null;
  }

  try {
    return JSON.parse(user);
  } catch {
    return null;
  }
};

// ================================
// GET USER ROLE
// ================================
export const getUserRole = () => {
  const user = getCurrentUser();

  return user?.role || null;
};

// ================================
// CHECK LOGIN
// ================================
export const isAuthenticated = () => {
  return !!localStorage.getItem("token");
};

// ================================
// CHECK ADMIN
// ================================
export const isAdmin = () => {
  return getUserRole() === "admin";
};

// ================================
// GET ALL USERS
// ================================
export const getUsers = async () => {
  try {
    const token = getToken();

    const response = await API.get("/users", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

export default API;